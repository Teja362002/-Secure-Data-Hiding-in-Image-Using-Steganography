# Secure Data Hiding in Image Using Steganography

This project implements **image steganography**, where secret messages are hidden inside images using the **Least Significant Bit (LSB) substitution** technique.

## Features
- Hide text messages inside an image without visual distortion.
- Extract hidden messages from a stego image.
- Uses Python and OpenCV for image processing.

## Installation
1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/Secure-Data-Hiding.git
   cd Secure-Data-Hiding
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage
### Encoding a Message:
Run the script to encode a message inside an image:
```bash
python encode.py --image original.png --message "Your hidden text"
```

### Decoding a Message:
To extract the hidden message:
```bash
python decode.py --image stego.png
```

## Example
![Original Image](images/original.png)  
![Stego Image](images/stego.png)

## Technologies Used
- **Python**
- **OpenCV**
- **NumPy**

## Author
Your Name  
Your Email

## License
This project is licensed under the MIT License.
